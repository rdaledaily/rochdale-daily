ROCHDALE DAILY — HOMEPAGE BUILD

Open index.html through a web server rather than by double-clicking it. For a local preview:

  cd rochdale-daily-site
  python -m http.server 8080

Then open http://localhost:8080/

WHAT CHANGED IN THIS VERSION
- The supplied Rochdale Daily clock-tower logo is used in the yellow masthead.
- The date and live Rochdale weather now share the black utility bar.
- On smaller screens the weather condenses to an icon and temperature in °C.
- The red breaking-news line is vertically centred.
- The homepage is ready for regularly pushed articles through fixed content slots.

ARTICLE FEED
The homepage checks these sources, in order, every five minutes:
  1. /api/articles
  2. articles.json

The response can be an array of articles or an object with this shape:

  {
    "breaking": "Optional breaking-news line",
    "articles": [ ... ]
  }

Useful article fields:
- id
- title
- kicker
- category
- area
- summary or excerpt
- image or image_url
- imageLabel or image_label
- byline or author
- body (array of paragraphs or a string)
- published_at or updated_at
- policeMatter or police_matter
- slot: lead, secondary-1, secondary-2, grid-1, grid-2, etc.
- priority: higher numbers appear first when no fixed slot wins

The included articles.json is the editable starter feed. A CMS, newsroom form, database or automation can replace it or publish to /api/articles. The layout updates without editing index.html.

DEVELOPER HELPERS
In the browser console:
  ROCHDALE_DAILY.refreshArticles()
  ROCHDALE_DAILY.showSlotLabels(true)

The second command reveals the internal homepage slot names for testing.

BEFORE PUBLICATION
- Replace or verify all example stories, dates and event listings.
- Connect forms to real services.
- Add verified local photography and image permissions.
- Confirm all public-service links and contact details.
- Configure a real cookie consent platform if non-essential analytics or advertising cookies are used.
